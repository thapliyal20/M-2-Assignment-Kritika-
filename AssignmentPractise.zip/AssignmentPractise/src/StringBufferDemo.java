import java.util.Scanner;


public class StringBufferDemo
{

	public static void main(String[] args) 
	{
		//StringBuffer strb=new StringBuffer("Praseeda");		//When we give values
		Scanner sc=new Scanner(System.in);
		StringBuffer strb=new StringBuffer("");
		strb.append(sc.next());
		strb.append(" Prasanan");
		System.out.println(strb);
		
		
	}

}
