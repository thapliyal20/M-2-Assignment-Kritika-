enum Gender {
	M,F;
}
public class Person 
{
	private String fpersonName;
	private String lpersonName;
	private Gender gender;
	
	
	public String getFpersonName() {
		return fpersonName;
	}


	public void setFpersonName(String fpersonName) {
		this.fpersonName = fpersonName;
	}


	public String getLpersonName() {
		return lpersonName;
	}


	public void setLpersonName(String lpersonName) {
		this.lpersonName = lpersonName;
	}


	public Gender getGender() {
		return gender;
	}


	public void setGender(Gender gender) {
		this.gender = gender;
	}

	

	public Person(String fpersonName, String lpersonName, Gender gender) {
		this.fpersonName = fpersonName;
		this.lpersonName = lpersonName;
		this.gender = gender;
	}


	public Person() {
		
	}

 
	
	
}
