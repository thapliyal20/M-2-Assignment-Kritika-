import java.util.Scanner;

public class TestForPerson {

	public static void main(String[] args) {
		
		System.out.println("Enter gender 1");
		Scanner sc=new Scanner(System.in);
		String gen= sc.next();
		
		Person p1 = new Person("Kritika","Thapliyal",Gender.valueOf(gen));
		Person p2 = new Person();
		
		p2.setFpersonName("Himanshu");
		p2.setLpersonName("Kemwal");
		System.out.println("Enter gender 2");
		gen= sc.next();
		p2.setGender(Gender.valueOf(gen));
		
		
		System.out.println("The details are:  ");
		System.out.println(p1.getFpersonName()+" "+p1.getLpersonName()+" "+p1.getGender());
		
		System.out.println(p2.getFpersonName()+" "+p2.getLpersonName()+" "+p2.getGender());
		

	}

}
