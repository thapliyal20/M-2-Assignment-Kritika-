import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Scanner;


public class DateFormatter1 {

	public static void main(String[] args) {
		
		String date1 = null;
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.println("Enter a date in dd/MM/yyyy: ");
		date1 = scInput.nextLine();
		
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		
		LocalDate dateNow = LocalDate.now();

	}

}
