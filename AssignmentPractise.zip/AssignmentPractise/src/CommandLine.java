
public class CommandLine 
{

	public static void main(String[] args)
	{
		int num1, num2, sum=0;
		num1=Integer.parseInt(args [0]);
		num2=Integer.parseInt(args [1]);
		
		sum = num1 + num2;
		
		System.out.println(" The value is :" +sum);
		

	}

}
